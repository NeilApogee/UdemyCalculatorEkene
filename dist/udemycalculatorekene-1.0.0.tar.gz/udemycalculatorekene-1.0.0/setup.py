
from setuptools import setup, find_packages

setup(
      name="UdemyCalculatorEkene",
      version="1.0.0",
      packages=find_packages(include=['udemyCalculator', 'udemyCalculator.*']),
      install_require=[],
      url="",
      LICENCE="",
      author = "Ekenedirichukwu Obianom",
      description = "This is my first trial on building a package."
      )